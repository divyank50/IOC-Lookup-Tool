document.getElementById("lookupBtn").addEventListener("click", function () {
    const source = document.getElementById("sourceSelect").value;
    const inputValue = document.getElementById("iocInput").value.trim();
    const resultDiv = document.getElementById("result");

    if (!inputValue) {
        resultDiv.innerHTML = "<p style='color:red;'>Please enter a value.</p>";
        return;
    }

    // Send message to background.js
    chrome.runtime.sendMessage({ 
        action: "lookupIOC", 
        data: { type: source, value: inputValue } 
    }, function (response) {
        if (response && response.success) {
            let output = `<h3>${response.data.source} Result:</h3>`;
            Object.entries(response.data).forEach(([key, value]) => {
                if (key !== "source") {
                    output += `<p><strong>${key.replace("_", " ")}:</strong> ${value}</p>`;
                }
            });
            
            resultDiv.innerHTML = output;
        }
       else if (source === "virustotal_file") {
            // Format VirusTotal File Report response
            output += `
            <p><strong>File Hash:</strong> ${response.data.file_hash}</p>
            <p><strong>VT Score:</strong> ${response.data.last_analysis_score}</p>
            <p><strong>Last Submission:</strong> ${response.data.last_submission_date}</p>
            <p><strong>File Type:</strong> ${response.data.type}</p>
            <p><strong>Magic:</strong> ${response.data.magic}</p>
            <p><strong>Community Score:</strong> ${response.data.reputation}</p>
            <p><strong>Popular Threat Label:</strong> ${response.data.popular_threat_label}</p>
            <p><strong>Popular Threat Category:</strong> ${response.data.popular_threat_category}</p>
            <p><strong>Family Labels:</strong> ${response.data.family_labels}</p>
            <p><strong>Associated Filenames:</strong></p>
                <ul>
                    ${response.data.associated_filenames.split(", ").map(name => `<li>${name}</li>`).join("")}
                </ul>

        `;
        
        } else if (source === "virustotal") {
            output += `
            <p><strong>IP Address:</strong> ${response.data.ip}</p>
            <p><strong>VT Score:</strong> ${response.data.last_analysis_score}</p> 
            <p><strong>Community Score:</strong> ${response.data.reputation}</p>
            <p><strong>Country:</strong> ${response.data.country}</p>
            <p><strong>Network:</strong> ${response.data.network}</p>
            <p><strong>Whois Information:</strong><br> ${response.data.whois}</p>
            `;
        }
        
        else {
            resultDiv.innerHTML = `<p style='color:red;'>${response.error}</p>`;
        }
    });
});
