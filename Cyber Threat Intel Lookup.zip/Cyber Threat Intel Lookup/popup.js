document.getElementById("lookupBtn").addEventListener("click", function () {
    const source = document.getElementById("sourceSelect").value;
    const inputValue = document.getElementById("iocInput").value.trim();
    const resultDiv = document.getElementById("result");

    if (!inputValue) {
        resultDiv.innerHTML = "<p style='color:red;'>Please enter a value.</p>";
        return;
    }

    // Send message to background.js
    chrome.runtime.sendMessage({ 
        action: "lookupIOC", 
        data: { type: source, value: inputValue } 
    }, function (response) {
        if (response && response.success) {
            let output = `<h3>${response.data.source} Result:</h3>`;
            Object.entries(response.data).forEach(([key, value]) => {
                if (key !== "source") {
                    output += `<p><strong>${key.replace("_", " ")}:</strong> ${value}</p>`;
                }
            });
            resultDiv.innerHTML = output;
        } else {
            resultDiv.innerHTML = `<p style='color:red;'>${response.error}</p>`;
        }
    });
});
