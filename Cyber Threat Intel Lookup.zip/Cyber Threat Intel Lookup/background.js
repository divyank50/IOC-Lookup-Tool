chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "lookupIOC") {
        const queryData = message.data;

        if (queryData.type === "malwarebazaar") {
            fetch("https://mb-api.abuse.ch/api/v1/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `query=get_info&hash=${encodeURIComponent(queryData.value)}`
            })
            .then(response => response.json())
            .then(data => {
                if (data.query_status === "hash_not_found") {
                    sendResponse({ success: false, error: "Hash not found in MalwareBazaar." });
                } else if (data.query_status === "ok" && Array.isArray(data.data) && data.data.length > 0) {
                    const malwareInfo = data.data[0];

                    let yaraRules = "None";
                    if  (malwareInfo.yara_rules && Array.isArray(malwareInfo.yara_rules)){
                        const limitedRules = malwareInfo.yara_rules.slice(0,2);
                        yaraRules = limitedRules.map(rules => 
                            `<a href="${rules.reference}" target="_blank">${rules.rule_name}</a>`
                        ).join(", ");
                    }

                    sendResponse({ 
                        success: true, 
                        data: {
                            source: "MalwareBazaar",
                            sha256: malwareInfo.sha256_hash || "N/A",
                            md5: malwareInfo.md5_hash || "N/A",
                            file_name: malwareInfo.file_name || "Unknown",
                            file_type: malwareInfo.file_type || "Unknown",
                            file_type_mime: malwareInfo.file_type_mime || "Unknown",
                            trid: malwareInfo.trid || "Unknown",
                            first_seen: malwareInfo.first_seen || "Unknown",
                            last_seen: malwareInfo.last_seen || "Unknown",
                            delivery_method: malwareInfo.delivery_method || "Unknown",
                            reporter: malwareInfo.reporter || "Unkown",
                            origin_country: malwareInfo.origin_country || "Unknown",
                            tags: malwareInfo.tags ? malwareInfo.tags.join(", ") : "None",
                            yara_rules: yaraRules
                        }
                    });
                } else {
                    sendResponse({ success: false, error: "Unexpected MalwareBazaar response." });
                }
            })
            .catch(error => {
                sendResponse({ success: false, error: "Failed to fetch MalwareBazaar." });
            });
        }

        else if (queryData.type === "threatfox") {
            fetch("https://threatfox-api.abuse.ch/api/v1/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    query: "search_ioc",
                    search_term: queryData.value,
                    exact_match: true
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.query_status === "ok" && data.data.length > 0) {
                    const result = data.data[0];

                    sendResponse({
                        success: true,
                        data: {
                            source: "ThreatFox",
                            ioc: result.ioc || "Unknown",
                            threat_type: result.threat_type || "Unknown",
                            malware: result.malware_printable || "Unknown",
                            confidence_level: result.confidence_level || "Unknown",
                            reporter: result.reporter || "Unknown",
                            first_seen: result.first_seen || "Unknown",
                            last_seen: result.last_seen || "N/A",
                            reference: result.reference ? `<a href="${result.reference}" target="_blank">Link</a>` : "None",
                            tags: result.tags || "Unkown"
                        }
                    });
                } else {
                    sendResponse({ success: false, error: "No results found in ThreatFox." });
                }
            })
            .catch(error => {
                sendResponse({ success: false, error: "Failed to fetch ThreatFox." });
            });
        }

        else if (queryData.type === "urlhaus") {
            console.log(`Sending request to URLHaus API for: ${queryData.value}`);
            
            fetch("https://urlhaus-api.abuse.ch/v1/url/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `url=${encodeURIComponent(queryData.value)}`
            })
            .then(response => response.json())
            .then(data => {
                console.log("URLHaus API Response:", data);

                if (data.query_status === "ok") {

                    let payloadInfo="None";
                    if (data.payloads && Array.isArray(data.payloads)&& data.payloads.length >0) {
                        const firstPayload = data.payloads[0];

                        payloadInfo = `
                    <p><strong>File Type:</strong> ${firstPayload.file_type || "Unknown"}</p>
                    <p><strong>SHA256:</strong> <a href="https://bazaar.abuse.ch/browse.php?search=${firstPayload.response_sha256}" target="_blank">${firstPayload.response_sha256}</a></p>
                    <p><strong>VT Results:</strong> ${firstPayload.virustotal ? `<a href="${firstPayload.virustotal.link}" target="_blank">${firstPayload.virustotal.result} Detection</a>` : "Unknown"}</p>
                    `;
                    }
                    sendResponse({
                        success: true,
                        data: {
                            source: "URLHaus",
                            url: data.url || "N/A",
                            host: data.host || "Unknown",
                            Url_status: data.url_status || "Unknown",
                            Date_Added: data.date_added || "Unknown",
                            last_online: data.last_online || "Unknown",
                            threat: data.threat || "Unknown",
                            tags: data.tags ? data.tags.join(", ") : "None",
                            Payload_Delivery: payloadInfo || "unkown",
                            reference: data.urlhaus_reference ? `<a href="${data.urlhaus_reference}" target="_blank">Link</a>` : "None"
                        }
                    });
                } else {
                    sendResponse({ success: false, error: "No results found in URLHaus." });
                }
            })
            .catch(error => {
                console.error("Error fetching URLHaus API:", error);
                sendResponse({ success: false, error: "Failed to fetch URLHaus." });
            });
        }

        return true; // Keeps async function alive for response
    }
});
